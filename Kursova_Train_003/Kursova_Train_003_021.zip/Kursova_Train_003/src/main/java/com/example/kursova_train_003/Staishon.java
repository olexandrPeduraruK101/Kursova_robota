package com.example.kursova_train_003;

public class Staishon {
    private int id;
    private String name_Staishon;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName_Staishon() {
        return name_Staishon;
    }

    public void setName_Staishon(String name_Staishon) {
        this.name_Staishon = name_Staishon;
    }
}
